package handler_test

import (
	"testing"
)

func TestHandlePfcpAssociationSetupRequest(t *testing.T) {
}

func TestHandlePfcpAssociationReleaseRequest(t *testing.T) {
}
