package context

import (
	"github.com/free5gc/smf/pkg/factory"
)

func SetupSMFContext(config *factory.Config) error {
	return nil
}
